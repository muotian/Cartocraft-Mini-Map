advancement revoke @s only algol.fwb:zzz/drop_from_saddle 
item replace entity @s saddle with air
