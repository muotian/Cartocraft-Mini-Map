scoreboard players set #break al.zzz 0
execute on attacker if entity @s[gamemode=creative] run scoreboard players set #break al.zzz 1
execute if score #break al.zzz matches 1 run return run function algol.fwb:zzz/break
execute on attacker run function algol.fwb:zzz/give_item
