execute at 00000a04-0000-0000-0000-000000000001 run return run fill ~-2 ~-1 ~-2 ~2 ~1 ~2 air replace barrier
schedule function a4:puzzle/unlock_woolbox 1 replace
