schedule function a4:puzzle/sync 10s replace
execute as @e[tag=a4.lantern,type=item_display] at @s run function a4:puzzle/sync/as_lantern_display with entity @s data."a4/lantern"
execute as @e[tag=a4.submit,type=item_display] at @s if block ~ ~-1 ~ air run function a4:puzzle/sync/remove_button
