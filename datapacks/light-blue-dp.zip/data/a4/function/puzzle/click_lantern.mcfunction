execute if data storage a4:puzzle solved run return fail
$execute store result score #state a4.v run data get storage a4:puzzle lanterns.$(id)
scoreboard players add #state a4.v 1
execute if score #state a4.v matches 2.. run scoreboard players set #state a4.v 0
$execute store result storage a4:puzzle lanterns.$(id) byte 1 run scoreboard players get #state a4.v
execute if score #state a4.v matches 0 run playsound block.copper_bulb.turn_off block @a ~ ~ ~
execute if score #state a4.v matches 0 run return run execute positioned ~ ~0.5 ~ run item modify entity @e[tag=a4.lantern,type=item_display,distance=..0.01,limit=1] contents a4:lantern/off
playsound block.copper_bulb.turn_on block @a ~ ~ ~
execute positioned ~ ~0.5 ~ run item modify entity @e[tag=a4.lantern,type=item_display,distance=..0.01,limit=1] contents a4:lantern/on
