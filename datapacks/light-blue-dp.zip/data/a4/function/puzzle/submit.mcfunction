execute if data storage a4:puzzle solved run return fail
execute store result score #submission a4.v run data get storage a4:puzzle lanterns.2
execute store result score #incr a4.v run data get storage a4:puzzle lanterns.5 2
scoreboard players operation #submission a4.v += #incr a4.v
execute store result score #incr a4.v run data get storage a4:puzzle lanterns.1 4
scoreboard players operation #submission a4.v += #incr a4.v
execute store result score #incr a4.v run data get storage a4:puzzle lanterns.4 8
scoreboard players operation #submission a4.v += #incr a4.v
execute store result score #incr a4.v run data get storage a4:puzzle lanterns.6 16
scoreboard players operation #submission a4.v += #incr a4.v
execute store result score #incr a4.v run data get storage a4:puzzle lanterns.3 32
execute store result storage a4:op macro.puzzle_hash.value int 114.514 run scoreboard players operation #submission a4.v += #incr a4.v
execute store result score #submission a4.v run function a4:puzzle/submit/hash with storage a4:op macro.puzzle_hash
tag @s add a4.ctx.submit
execute if score #submission a4.v matches 1258072215 run return run function a4:puzzle/submit/correct
function a4:puzzle/submit/wrong
