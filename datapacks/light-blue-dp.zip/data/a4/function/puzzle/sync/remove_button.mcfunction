execute positioned ~ ~-0.5 ~ run kill @e[tag=a4.pedestal,type=item_display,distance=..0.01,limit=1]
execute positioned ~ ~-0.5 ~ run kill @e[tag=a4.submit,type=text_display,distance=..0.01,limit=1]
execute positioned ~ ~0.5 ~ run kill @e[tag=a4.submit.message,type=text_display,distance=..0.01,limit=1]
kill @e[tag=a4.submit,type=interaction,distance=..0.01,limit=1]
kill @s
