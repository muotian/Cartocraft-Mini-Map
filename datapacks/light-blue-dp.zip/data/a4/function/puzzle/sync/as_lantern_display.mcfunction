execute if block ~ ~-1 ~ air run return run function a4:puzzle/sync/remove_lantern
$execute if data storage a4:puzzle lanterns{$(id): 0b} run item modify entity @s contents a4:lantern/off
$execute if data storage a4:puzzle lanterns{$(id): 1b} run item modify entity @s contents a4:lantern/on
