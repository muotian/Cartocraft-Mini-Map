execute positioned ~ ~-1 ~ run kill @e[tag=a4.pedestal,type=item_display,distance=..0.01,limit=1]
execute positioned ~ ~-1 ~ run kill @e[tag=a4.lantern,type=text_display,distance=..0.01,limit=1]
execute positioned ~ ~-0.5 ~ run kill @e[tag=a4.lantern,type=interaction,distance=..0.01,limit=1]
kill @s
