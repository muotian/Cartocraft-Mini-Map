$damage @s $(penalty) generic
execute store result score #penalty a4.v run data get storage a4:puzzle penalty
execute unless score #penalty a4.v matches 100.. run scoreboard players add #penalty a4.v 4
execute store result storage a4:puzzle penalty int 1 run scoreboard players get #penalty a4.v
