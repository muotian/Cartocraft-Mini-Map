execute if entity @s[tag=!a4.ctx.submit] run return run tellraw @s {translate:"text.a4.puzzle.cheat_detected",color:"red"}
data modify storage a4:puzzle lanterns set value {1:1b,2:1b,3:1b,4:1b,5:1b,6:1b}
function a4:puzzle/sync
data modify storage a4:puzzle solved set value {}
playsound block.vault.insert_item block @a ~ ~ ~
item replace entity @e[tag=a4.submit,type=item_display,distance=..0.01,limit=1] contents with bedrock
execute positioned ~ ~-0.5 ~ run data modify entity @e[tag=a4.submit,type=text_display,distance=..0.01,limit=1] view_range set value 0.0f
execute positioned ~ ~0.5 ~ run data modify entity @e[tag=a4.submit.message,type=text_display,distance=..0.01,limit=1] text set value {translate:"text.a4.puzzle.solved",color:"aqua"}
function a4:puzzle/unlock_woolbox
