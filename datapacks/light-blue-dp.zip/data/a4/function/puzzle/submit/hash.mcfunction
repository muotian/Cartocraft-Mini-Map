$random reset a4:puzzle_hash $(value) false true
return run random value 1..2147483647 a4:puzzle_hash
