execute if entity @s[gamemode=!creative,gamemode=!spectator] run function a4:puzzle/apply_penalty with storage a4:puzzle
playsound entity.villager.no block @a ~ ~ ~
data modify storage a4:puzzle lanterns set value {1:0b,2:0b,3:0b,4:0b,5:0b,6:0b}
function a4:puzzle/sync
execute positioned ~ ~0.5 ~ run data modify entity @e[tag=a4.submit.message,type=text_display,distance=..0.01,limit=1] text set value {translate:"text.a4.puzzle.penalty",with:[{text:"\u2192",font:"a4:seven",color:"#ddffff"},{storage:"a4:puzzle",nbt:"penalty"}]}
