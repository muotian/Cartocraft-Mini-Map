function a4:item/aoe_armor/select_damage
effect clear @s absorption
advancement revoke @s only a4:trigger_aoe_armor
