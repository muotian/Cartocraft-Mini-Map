execute if predicate a4:has_absorption/lv1 run return run function a4:item/aoe_armor/deal_damage/baked_56q41baa3fk3c
execute if predicate a4:has_absorption/lv2 run return run function a4:item/aoe_armor/deal_damage/baked_3hncrkdhvjid3
execute if predicate a4:has_absorption/lv3 run return run function a4:item/aoe_armor/deal_damage/baked_3nu7r3tvsfxda
execute if predicate a4:has_absorption/lv4 run return run function a4:item/aoe_armor/deal_damage/baked_399gkp92p549u
function a4:item/aoe_armor/deal_damage/baked_3ctdskwh3qdt2
