tag @s add this
execute as @e[type=!#a4:object_entity,type=!player,distance=..15] run damage @s 30 a4:aoe_armor by @a[tag=this,limit=1,x=0]
tag @s remove this
