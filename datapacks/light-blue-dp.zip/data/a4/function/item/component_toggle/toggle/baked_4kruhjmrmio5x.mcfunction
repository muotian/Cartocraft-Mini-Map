item modify entity @s weapon.mainhand a4:component_toggle/step_1
item modify entity @s weapon.mainhand a4:component_toggle/step_2
