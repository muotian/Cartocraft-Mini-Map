$item modify entity @s weapon.$(hand) a4:component_toggle/step_1
$item modify entity @s weapon.$(hand) a4:component_toggle/step_2
