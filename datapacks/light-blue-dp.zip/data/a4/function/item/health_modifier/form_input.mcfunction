function a4:item/health_modifier/set_health/step_1
function a4:dialog/close
