function a4:dialog/show/baked_7mnedh1thqokh
advancement revoke @s only a4:use_health_modifier
