$attribute @s max_health modifier add a4:modify_health $(amount) add_multiplied_total
scoreboard players set @s a4.modifying_health 1
effect give @s instant_health 1 27 true
