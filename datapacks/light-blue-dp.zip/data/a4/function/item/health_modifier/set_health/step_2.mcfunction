attribute @s max_health modifier remove a4:modify_health
scoreboard players set @s a4.modifying_health 0
advancement revoke @s only a4:health_modifier_step_2
