tellraw @s {translate:"text.a4.health_modifier.result",with:[{score:{name:"@s",objective:"a4.form_input"}}]}
execute store result storage a4:op macro.attribute.amount double 0.01 run scoreboard players remove @s a4.form_input 100
function a4:item/health_modifier/set_health/apply_modifier with storage a4:op macro.attribute
