advancement revoke @s only a4:use_copper_miner
execute if items entity @s weapon.mainhand *[custom_data~{"a4/copper_miner":{}}] run return run function a4:item/copper_miner/transform/baked_4kruhjmrmio5x
execute if items entity @s weapon.offhand *[custom_data~{"a4/copper_miner":{}}] run function a4:item/copper_miner/transform/baked_b6zq5r8w5c8n
