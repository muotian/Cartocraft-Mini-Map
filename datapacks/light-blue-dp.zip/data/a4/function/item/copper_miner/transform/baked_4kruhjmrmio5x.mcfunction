execute if items entity @s weapon.mainhand *[custom_data~{"a4/copper_miner":{mode:"axe"}}] run return run item modify entity @s weapon.mainhand a4:copper_miner/pickaxe_mode
item modify entity @s weapon.mainhand a4:copper_miner/axe_mode
