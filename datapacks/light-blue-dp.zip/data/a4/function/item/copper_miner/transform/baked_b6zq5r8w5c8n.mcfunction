execute if items entity @s weapon.offhand *[custom_data~{"a4/copper_miner":{mode:"axe"}}] run return run item modify entity @s weapon.offhand a4:copper_miner/pickaxe_mode
item modify entity @s weapon.offhand a4:copper_miner/axe_mode
