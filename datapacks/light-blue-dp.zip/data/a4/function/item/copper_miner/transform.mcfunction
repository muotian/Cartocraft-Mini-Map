$execute if items entity @s weapon.$(hand) *[custom_data~{"a4/copper_miner": {mode: "axe"}}] run return run item modify entity @s weapon.$(hand) a4:copper_miner/pickaxe_mode
$item modify entity @s weapon.$(hand) a4:copper_miner/axe_mode
