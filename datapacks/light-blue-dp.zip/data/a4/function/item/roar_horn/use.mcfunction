advancement revoke @s only a4:toot_roar_horn
execute store result score #dt a4.v run time query gametime
scoreboard players operation #dt a4.v -= @s a4.roar_horn_time
execute unless score @s a4.roar_horn_time = @s a4.roar_horn_time run scoreboard players set #dt a4.v 0
execute if score #dt a4.v matches 1..140 run return fail
effect give @e[type=!#a4:object_entity,distance=..12] wither 7 2
execute store result score @s a4.roar_horn_time run time query gametime
