scoreboard players reset @s a4.roar_horn_time
