execute if items entity @s weapon.mainhand *[consumable,custom_data~{"a4/infinite":1b}] run function a4:item/component_toggle/toggle/baked_4kruhjmrmio5x
execute if items entity @s weapon.offhand *[consumable,custom_data~{"a4/infinite":1b}] run function a4:item/component_toggle/toggle/baked_b6zq5r8w5c8n
advancement revoke @s only a4:consume_infinite_item
