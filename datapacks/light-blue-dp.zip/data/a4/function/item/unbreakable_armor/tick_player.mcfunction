execute store result score #cur a4.v if items entity @s armor.* *[unbreakable]
execute unless items entity @s armor.chest *[custom_data~{"a4/item_id":"unbreakable_armor"}] run scoreboard players set #cur a4.v 0
execute unless score @s a4.unbreakable_count = #cur a4.v run function a4:item/unbreakable_armor/update_attribute
