scoreboard players set @s a4.unbreakable_count 0
