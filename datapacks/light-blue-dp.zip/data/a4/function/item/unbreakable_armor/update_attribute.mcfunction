scoreboard players operation @s a4.unbreakable_count = #cur a4.v
attribute @s armor_toughness modifier remove a4:unbreakable_armor
execute if score @s a4.unbreakable_count matches 0 run return 1
execute if score @s a4.unbreakable_count matches 1 run return run attribute @s armor_toughness modifier add a4:unbreakable_armor 0.7 add_value
execute if score @s a4.unbreakable_count matches 2 run return run attribute @s armor_toughness modifier add a4:unbreakable_armor 1.4 add_value
execute if score @s a4.unbreakable_count matches 3 run return run attribute @s armor_toughness modifier add a4:unbreakable_armor 2.1 add_value
attribute @s armor_toughness modifier add a4:unbreakable_armor 2.8 add_value
