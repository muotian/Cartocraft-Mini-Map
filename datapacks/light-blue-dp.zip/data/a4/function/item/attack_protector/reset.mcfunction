execute if score @s a4.prot_hurt_count matches 1.. if items entity @s weapon.offhand *[enchantments~[{enchantments:"a4:zzz/item/attack_protector"}]] run playsound a4:item.attack_protector.reset player @s ~ ~ ~
scoreboard players set @s a4.prot_hurt_count 0
advancement revoke @s only a4:reset_item_protector
