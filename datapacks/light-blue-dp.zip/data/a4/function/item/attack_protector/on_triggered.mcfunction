execute if score @s a4.prot_hurt_count matches 0 run playsound a4:item.attack_protector.trigger.1 player @s ~ ~ ~
execute if score @s a4.prot_hurt_count matches 1 run playsound a4:item.attack_protector.trigger.2 player @s ~ ~ ~
scoreboard players add @s a4.prot_hurt_count 1
advancement revoke @s only a4:trigger_item_protector
