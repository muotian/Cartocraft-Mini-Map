scoreboard players add @s a4.prot_hurt_count 0
