tellraw @s {translate:"text.a4.music_disc_info",with:[{translate:"a4.music"},{text:"https://youtu.be/7vXZlHYWjeU",color:"#9999ff",underlined:true,click_event:{action:"open_url",url:"https://youtu.be/7vXZlHYWjeU"}}],color:"#ddffff"}
advancement revoke @s only a4:play_bgm_disc
