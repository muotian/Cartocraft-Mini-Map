execute store result score #result a4.v if predicate a4:is_fire_armor_active
execute if score #result a4.v matches 1 run attribute @s attack_damage modifier add a4:fire_armor 3 add_value
execute if score #result a4.v matches 1 run return run attribute @s armor modifier add a4:fire_armor -0.5 add_multiplied_base
attribute @s attack_damage modifier remove a4:fire_armor
attribute @s armor modifier remove a4:fire_armor
