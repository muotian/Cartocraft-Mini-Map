execute if predicate a4:is_eclipse_rune_active run return run attribute @s attack_damage modifier add a4:eclipse_rune 0.6 add_multiplied_base
attribute @s attack_damage modifier remove a4:eclipse_rune
