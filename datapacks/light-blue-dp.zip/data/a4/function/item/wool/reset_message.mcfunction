advancement revoke @s only a4:consume_wool
