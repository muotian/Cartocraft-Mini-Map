tellraw @s {translate:"text.a4.wool.eaten"}
