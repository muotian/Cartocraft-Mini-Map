execute if score @s a4.cinnabar_mask_cooldown matches 1.. run scoreboard players remove @s a4.cinnabar_mask_cooldown 1
execute if score @s a4.cinnabar_mask_cooldown matches 1.. run return 1
execute unless items entity @s armor.head *[custom_data~{"a4/item_id":"cinnabar_mask"}] run return 1
effect give @s absorption 30 0
scoreboard players set @s a4.cinnabar_mask_cooldown 600
