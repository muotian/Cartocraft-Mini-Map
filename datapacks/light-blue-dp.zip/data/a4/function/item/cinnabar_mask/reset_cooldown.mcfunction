scoreboard players set @s a4.cinnabar_mask_cooldown 0
