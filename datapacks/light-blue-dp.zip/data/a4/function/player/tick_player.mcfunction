tag @s remove a4.ctx.submit
execute if score @s a4.active_dialog matches 1.. run function a4:dialog/handle_input
execute if score @s a4.active_dialog matches 1.. run scoreboard players enable @s a4.input
execute if score @s a4.active_dialog matches 1.. run scoreboard players enable @s a4.form_input
function a4:item/cinnabar_mask/tick_player
function a4:item/fire_armor/tick_player
function a4:item/unbreakable_armor/tick_player
function a4:item/eclipse_rune/tick_player
