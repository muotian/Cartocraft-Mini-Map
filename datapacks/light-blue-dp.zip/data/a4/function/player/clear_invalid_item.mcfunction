schedule function a4:player/clear_invalid_item 4s replace
clear @a *[enchantments~[{enchantments:"#a4:invalid_on_player"}]]
