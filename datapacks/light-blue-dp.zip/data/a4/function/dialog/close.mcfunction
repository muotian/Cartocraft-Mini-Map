scoreboard players set @s a4.active_dialog 0
scoreboard players reset @s a4.input
scoreboard players reset @s a4.form_input
dialog clear @s
