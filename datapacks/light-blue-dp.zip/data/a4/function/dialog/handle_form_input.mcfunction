execute store result storage a4:op macro.dialog.id int 1 run scoreboard players get @s a4.active_dialog
function a4:dialog/handle_form_input/load_command with storage a4:op macro.dialog
function a4:dialog/handle_form_input/eval with storage a4:op macro.eval
scoreboard players set @s a4.input 0
scoreboard players set @s a4.form_input -2147483648
