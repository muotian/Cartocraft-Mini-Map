data remove storage a4:op macro.eval
$data modify storage a4:op macro.eval.run set from storage a4:dialog dialogs.$(id).form_input
