$execute unless data storage a4:dialog dialogs.$(id).show run return fail
$function a4:dialog/show/eval with storage a4:dialog dialogs.$(id)
$scoreboard players set @s a4.active_dialog $(id)
scoreboard players enable @s a4.input
scoreboard players enable @s a4.form_input
scoreboard players set @s a4.input 0
scoreboard players set @s a4.form_input -2147483648
