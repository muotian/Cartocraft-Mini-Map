execute unless data storage a4:dialog dialogs.1.show run return fail
function a4:dialog/show/eval with storage a4:dialog dialogs.1
scoreboard players set @s a4.active_dialog 1
scoreboard players enable @s a4.input
scoreboard players enable @s a4.form_input
scoreboard players set @s a4.input 0
scoreboard players set @s a4.form_input -2147483648
