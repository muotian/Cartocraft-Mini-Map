execute if score @s a4.input matches -1 run return run function a4:dialog/close
execute if score @s a4.form_input matches -2147483647.. run return run function a4:dialog/handle_form_input
execute unless score @s a4.input matches 1.. run return 1
execute store result storage a4:op macro.dialog.id int 1 run scoreboard players get @s a4.active_dialog
execute store result storage a4:op macro.dialog.input int 1 run scoreboard players get @s a4.input
function a4:dialog/handle_input/load_command with storage a4:op macro.dialog
function a4:dialog/handle_input/eval with storage a4:op macro.eval
scoreboard players set @s a4.input 0
