execute as @a at @s run function a4:player/tick_player
execute as @e[tag=a4.trader,type=mannequin] at @s run function a4:entity/trader/rotate_mannequin
kill @e[tag=a4.padding,predicate=!a4:is_valid_padding,type=interaction]
kill @e[tag=a4.nametag,predicate=!a4:has_vehicle,type=text_display]
kill @e[tag=a4.trader,predicate=!a4:has_vehicle,type=wandering_trader]
kill @e[tag=a4.mob.very_weak_to_fire,predicate=a4:is_on_fire,type=zombie]
