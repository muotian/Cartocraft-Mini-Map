effect clear @s slowness
effect give @s speed 8 1
