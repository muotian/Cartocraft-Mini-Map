kill @s
summon marker ~ ~ ~ {UUID:[I;2564,0,0,1],Tags:["a4.woolbox"]}
