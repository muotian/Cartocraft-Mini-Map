data modify storage codex:description_keys values append value {id:"a4:enchantment/fire_bane",related_keywords:["minecraft:enchantable/weapon"]}
data modify storage codex:description_keys values[-1].context_number set from storage codex:inspecting_item root.components."minecraft:stored_enchantments"."a4:fire_bane"
