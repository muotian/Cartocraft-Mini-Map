data modify storage codex:description_keys values append value {id:"a4:enchantment/slowness_bane",related_keywords:[{id:"minecraft:effect/speed",context_number:1}]}
