data modify storage codex:description_keys values append value {id:"a4:enchantment/chaos"}
data modify storage codex:description_keys values[-1].context_number set from storage codex:inspecting_item root.components."minecraft:enchantments"."a4:chaos"
data modify storage codex:description_keys values append value {id:"a4:extra/chaos_effects",related_keywords:[{id:"minecraft:effect/slowness",context_number:0},{id:"minecraft:effect/weakness",context_number:0},{id:"minecraft:effect/speed",context_number:0},{id:"minecraft:effect/strength",context_number:0}]}
