execute if items entity @s contents *[stored_enchantments~[{enchantments:"a4:fire_bane"}]] run function a4:codex/generated/2917346
execute if items entity @s contents *[stored_enchantments~[{enchantments:"a4:slowness_bane"}]] run function a4:codex/generated/b17dba2
execute if items entity @s contents *[stored_enchantments~[{enchantments:"a4:fire_breach"}]] run function a4:codex/generated/2b7a003
execute if items entity @s contents *[stored_enchantments~[{enchantments:"a4:chaos"}]] run function a4:codex/generated/753a02d
