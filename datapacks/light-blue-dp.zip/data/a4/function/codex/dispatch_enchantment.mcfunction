execute if items entity @s contents *[enchantments~[{enchantments:"a4:fire_bane"}]] run function a4:codex/generated/c2d7e84
execute if items entity @s contents *[enchantments~[{enchantments:"a4:slowness_bane"}]] run function a4:codex/generated/5fc0dab
execute if items entity @s contents *[enchantments~[{enchantments:"a4:fire_breach"}]] run function a4:codex/generated/3856705
execute if items entity @s contents *[enchantments~[{enchantments:"a4:chaos"}]] run function a4:codex/generated/cc2ebce
