scoreboard objectives add a4.v dummy
scoreboard objectives add a4.active_dialog dummy
scoreboard objectives add a4.input trigger
scoreboard objectives add a4.form_input trigger
scoreboard objectives add a4.roar_horn_time dummy
scoreboard objectives add a4.cinnabar_mask_cooldown dummy
scoreboard objectives add a4.modifying_health dummy
scoreboard objectives add a4.prot_hurt_count dummy
scoreboard objectives add a4.unbreakable_count dummy
team add a4.mob
execute unless data storage a4:puzzle lanterns run data modify storage a4:puzzle lanterns set value {1:0b,2:0b,3:0b,4:0b,5:0b,6:0b}
execute unless data storage a4:puzzle penalty run data modify storage a4:puzzle penalty set value 8
data modify storage a4:dialog dialogs set value {1:{show:"function a4:item/health_modifier/dialog/show_initial_100",inputs:{1:"function a4:item/health_modifier/dialog/show_initial_0",2:"function a4:item/health_modifier/dialog/show_initial_50",3:"function a4:item/health_modifier/dialog/show_initial_100"},form_input:"function a4:item/health_modifier/form_input"}}
function a4:codex/load_desc
execute as @e[tag=a4.woolbox,type=marker,limit=1] at @s run function a4:load/reset_marker/woolbox
schedule function a4:puzzle/sync 1 replace
schedule function a4:player/clear_invalid_item 1 replace
