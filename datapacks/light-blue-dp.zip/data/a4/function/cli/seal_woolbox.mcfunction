execute if entity @s[gamemode=!creative,gamemode=!spectator] run return fail
execute at 00000a04-0000-0000-0000-000000000001 run fill ~-2 ~-1 ~-2 ~2 ~1 ~2 barrier replace air strict
