execute if entity @s[gamemode=!creative,gamemode=!spectator] run return fail
data modify storage a4:puzzle lanterns set value {1:0b,2:0b,3:0b,4:0b,5:0b,6:0b}
data modify storage a4:puzzle penalty set value 8
data remove storage a4:puzzle solved
item replace entity @e[tag=a4.submit,type=item_display,limit=1] contents with emerald_block
data modify entity @e[tag=a4.submit,type=text_display,limit=1] view_range set value 1.0f
data modify entity @e[tag=a4.submit.message,type=text_display,limit=1] text set value {translate:"text.a4.puzzle.penalty",with:[{text:"\u2192",font:"a4:seven",color:"#ddffff"},{storage:"a4:puzzle",nbt:"penalty"}]}
function a4:cli/seal_woolbox
function a4:puzzle/sync
