give @s chest[container_loot={loot_table:"a4:loots/chest/regular"},item_name="regular chest"]
give @s chest[container_loot={loot_table:"a4:loots/chest/mega"},item_name="mega chest"]
