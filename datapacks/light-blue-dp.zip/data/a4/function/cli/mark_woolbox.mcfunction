execute if entity @s[gamemode=!creative,gamemode=!spectator] run return fail
kill 00000a04-0000-0000-0000-000000000001
execute at @n[tag=al.woolbox,type=item_display,distance=..10] align xyz run summon marker ~0.5 ~0.5 ~0.5 {UUID:[I;2564,0,0,1],Tags:["a4.woolbox"]}
