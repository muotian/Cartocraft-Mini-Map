execute if entity @s[gamemode=!creative,gamemode=!spectator] run return fail
setblock ~ ~ ~ barrier
execute align xyz run summon item_display ~0.5 ~0.5 ~0.5 {Tags:["a4.pedestal"],item:{id:"reinforced_deepslate"}}
$execute align xyz run summon interaction ~.5 ~1 ~.5 { height: .75, width: .5, response: 1b, Invulnerable: 1b, Tags: ["a4.lantern"], data: { "al/on_attack": {run: "function a4:puzzle/click_lantern {id: $(id)}"}, "al/on_interact": {run: "function a4:puzzle/click_lantern {id: $(id)}"} } }
$execute align xyz run summon item_display ~.5 ~1.5 ~.5 { Tags: ["a4.lantern"], data: {"a4/lantern": {id: $(id)}}, item: {id: "cod", components: {item_model: "a4:misc/lantern"}} }
$execute align xyz run summon text_display ~.5 ~.5 ~.5 { Tags: ["a4.lantern"], text: {text: "$(id)", font: "a4:seven"}, transformation: {left_rotation: [0f, 0f, 0f, 1f], right_rotation: [0f, 0f, 0f, 1f], scale: [1.5f, 1.5f, 1.5f], translation: [0f, -.17f, .501f]}, background: 0 }
execute align xyz positioned ~0.5 ~0.5 ~0.5 as @e[tag=a4.lantern,type=text_display,distance=..0.01,limit=1] positioned 0.0 0 0.0 rotated ~45 0 positioned ^ ^ ^-0.5 align xz facing -0.5 0 -0.5 run rotate @s ~135 0
return 1
$random value 1..$(id)
$random value $(id)..6
tag @s add a4.lantern
