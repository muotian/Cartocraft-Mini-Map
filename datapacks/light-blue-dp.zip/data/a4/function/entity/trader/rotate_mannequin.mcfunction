execute anchored eyes facing entity @p[gamemode=!spectator,distance=..5] eyes run return run rotate @s ~ ~
rotate @s ~ 0
