execute if items entity @s contents *[potion_contents] run item modify entity @s contents a4:remove_arrow_effect
