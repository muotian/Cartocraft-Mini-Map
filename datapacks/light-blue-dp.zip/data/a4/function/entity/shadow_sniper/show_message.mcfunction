tellraw @s {translate:"text.a4.tutorial.shadow_sniper"}
