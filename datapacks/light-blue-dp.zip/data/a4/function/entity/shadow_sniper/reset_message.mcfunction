advancement revoke @s only a4:take_heavy_damage_from_shadow_sniper
