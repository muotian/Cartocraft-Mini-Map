advancement grant @a[scores={lexica=1}] only triggerlexica:give_lexica
scoreboard players set @a lexica 0
scoreboard players enable @a lexica
