advancement revoke @s only triggerlexica:give_lexica
