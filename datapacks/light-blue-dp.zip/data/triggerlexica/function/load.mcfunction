scoreboard objectives add lexica trigger {translate:"codex.book",color:"#88ff88"}
