data modify storage codex:internal root.transforms."codex:format_text_with_bullet".out set value {translate:"codex.bullet.base",fallback:" %1$s%2$s",with:[]}
data modify storage codex:internal root.transforms."codex:format_text_with_bullet".out merge from storage codex:internal root.transforms."codex:format_text_with_bullet".in.style
function codex:proc/format_text_with_bullet/get_bullet_text with storage codex:internal root.transforms."codex:format_text_with_bullet".in
data modify storage codex:internal root.transforms."codex:format_text_with_bullet".out.with append from storage codex:internal root.transforms."codex:format_text_with_bullet".temp.bullet_text
data modify storage codex:internal root.transforms."codex:format_text_with_bullet".out.with append from storage codex:internal root.transforms."codex:format_text_with_bullet".in.content
