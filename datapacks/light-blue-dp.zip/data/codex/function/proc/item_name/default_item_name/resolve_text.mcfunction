summon item ~ ~ ~ {Item:{id:"stone"},Tags:["codex.name_resolver"]}
item replace entity @e[type=item,tag=codex.name_resolver,distance=..0.1,limit=1] contents from entity @s contents
data modify entity 24b09cde-0000-0000-0000-000000000004 text set value {selector:"@e[type=item, tag=codex.name_resolver, distance=...1, limit=1]"}
data modify storage codex:internal root.transforms."codex:item_name".temp.resolved_text set from entity 24b09cde-0000-0000-0000-000000000004 text
kill @e[type=item,tag=codex.name_resolver,distance=..0.1]
