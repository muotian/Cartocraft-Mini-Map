scoreboard players set #sound_type codex.var 0
item replace entity 24b09cde-0000-0000-0000-000000000001 contents from entity @s inventory.22
execute as 24b09cde-0000-0000-0000-000000000001 run function codex:main/modify_book
item replace entity @s inventory.22 from entity 24b09cde-0000-0000-0000-000000000001 contents
execute if score #sound_type codex.var matches 0 run return 1
execute if score #sound_type codex.var matches 1 run stopsound @s * item.bundle.insert
execute if score #sound_type codex.var matches 2..4 run stopsound @s * item.bundle.remove_one
execute if score #sound_type codex.var matches 1 at @s run playsound ui.cartography_table.take_result player @s ~ ~ ~ 0.6 1
execute if score #sound_type codex.var matches 1 at @s run playsound ui.cartography_table.take_result player @s ~ ~ ~ 0.6 1.1
execute if score #sound_type codex.var matches 1 at @s run return run playsound ui.cartography_table.take_result player @s ~ ~ ~ 0.6 1.2
execute if score #sound_type codex.var matches 2 at @s run playsound item.brush.brushing.generic player @s ~ ~ ~ 1 0.5
execute if score #sound_type codex.var matches 2 at @s run playsound item.brush.brushing.generic player @s ~ ~ ~ 1 0.6
execute if score #sound_type codex.var matches 2 at @s run playsound item.brush.brushing.generic player @s ~ ~ ~ 1 0.7
execute if score #sound_type codex.var matches 2 at @s run playsound item.brush.brushing.generic player @s ~ ~ ~ 1 0.8
execute if score #sound_type codex.var matches 2 at @s run return run playsound item.brush.brushing.generic player @s ~ ~ ~ 1 0.9
execute if score #sound_type codex.var matches 3 at @s run return run playsound item.book.page_turn player @s ~ ~ ~ 1 1.2
execute at @s run playsound item.bundle.insert_fail player @s ~ ~ ~ 0.75 2
execute at @s run playsound block.note_block.didgeridoo player @s ~ ~ ~ 0.7 1.5
