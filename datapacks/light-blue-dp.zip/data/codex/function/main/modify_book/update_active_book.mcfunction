scoreboard players set #sound_type codex.var 2
function codex:main/modify_book/load_book_data
execute if items entity @s contents *[bundle_contents~{items:{size:0}}] run return run function codex:main/modify_book/reset_book
execute if items entity 24b09cde-0000-0000-0000-000000000002 contents *[custom_data~{codex:{type:"button"}}] run return run function codex:main/modify_book/reset_book
scoreboard players set #sound_type codex.var 0
execute store result score #item_count codex.var run data get storage codex:internal root.book_item.item_stack.components."minecraft:bundle_contents"
execute store result score #entry_count codex.var run data get storage codex:internal root.book_item.baked_contents.active_page
scoreboard players remove #item_count codex.var 1
execute unless score #item_count codex.var < #entry_count codex.var run return 1
scoreboard players set #sound_type codex.var 3
execute if items entity 24b09cde-0000-0000-0000-000000000003 contents *[custom_data~{codex:{type:"button",action:"next_page"}}] if data storage codex:internal root.book_item.baked_contents.other_pages[0] run function codex:main/modify_book/next_page
execute if items entity 24b09cde-0000-0000-0000-000000000003 contents *[custom_data~{codex:{type:"button",action:"select_entry"}}] run function codex:main/modify_book/select_entry
function codex:main/modify_book/fill_bundle
function codex:main/modify_book/save_book_data
