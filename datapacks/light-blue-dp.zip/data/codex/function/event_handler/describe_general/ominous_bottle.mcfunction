data modify storage codex:description_keys values append value {id:"minecraft:effect/bad_omen",context_number:0}
data modify storage codex:description_keys values[-1].context_number set from storage codex:inspecting_item root.components."minecraft:ominous_bottle_amplifier"
data modify storage codex:description_keys values append value {id:"minecraft:effect/raid_omen",context_number:0,related_keywords:["codex:keyword/bad_omen_addition"]}
data modify storage codex:description_keys values[-1].context_number set from storage codex:inspecting_item root.components."minecraft:ominous_bottle_amplifier"
data modify storage codex:description_keys values append value {id:"minecraft:effect/trial_omen",related_keywords:["codex:keyword/bad_omen_addition"]}
