function codex:load/vanilla_description/effect/1
function codex:load/vanilla_description/effect/2
function codex:load/vanilla_description/effect/3
function codex:load/vanilla_description/effect/4
