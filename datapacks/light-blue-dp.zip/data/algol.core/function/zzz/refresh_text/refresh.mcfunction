execute store result score #shadow al.zzz run data get entity @s shadow
execute if score #shadow al.zzz matches 0 run data modify entity @s shadow set value 1b
execute if score #shadow al.zzz matches 0 run return run data modify entity @s shadow set value 0b
data modify entity @s shadow set value 0b
data modify entity @s shadow set value 1b
