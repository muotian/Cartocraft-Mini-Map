scoreboard players set #is_this al.zzz 0
execute on target run scoreboard players set #is_this al.zzz 1
execute if score #is_this al.zzz matches 0 run return fail
function algol.core:zzz/interaction/eval with entity @s data."al/on_interact"
data remove entity @s interaction
