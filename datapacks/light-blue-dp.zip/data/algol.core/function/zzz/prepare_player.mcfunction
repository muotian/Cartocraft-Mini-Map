scoreboard players set @s al.zzz.leave -1
data modify storage algol:zzz ser.uuid set from entity @s UUID
data modify storage algol:zzz macro.gu.UUID set from storage algol:zzz ser.uuid
function gu:convert with storage algol:zzz macro.gu
data modify storage algol:zzz macro.player_id.uuid_str set from storage gu:main out
function algol.core:zzz/prepare_player/load_id with storage algol:zzz macro.player_id
function algol.core:load_player_storage
data modify storage algol:player_storage value.uuid set from storage algol:zzz ser.uuid
data modify storage algol:player_storage value.uuid_str set from storage gu:main out
function #algol.core:event/join
tag @s remove al.new
