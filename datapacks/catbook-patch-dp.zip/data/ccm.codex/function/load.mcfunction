function ccm.codex:load/from_structure
