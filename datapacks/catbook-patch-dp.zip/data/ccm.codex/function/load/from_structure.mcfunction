execute unless loaded -30000000 0 1832230 run return run schedule function ccm.codex:load/from_structure 1
place template ccm.codex:data -30000000 0 1832230
execute positioned -30000000 0 1832230 run data modify storage codex:archives root merge from entity @e[tag=ccm.codex.data,type=marker,distance=..1,limit=1] data.load
kill @e[tag=ccm.codex.data,type=marker,limit=1]
