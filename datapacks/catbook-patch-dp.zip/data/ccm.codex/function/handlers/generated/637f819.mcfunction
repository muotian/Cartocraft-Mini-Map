data modify storage codex:description_keys values append value {id:"yellow:enchantment/soul_gem",related_keywords:["minecraft:enchantable/armor"]}
data modify storage codex:description_keys values append value {id:"yellow:extra/soul_gem_effects",related_keywords:["minecraft:effect/night_vision",{id:"minecraft:effect/absorption",context_number:0}]}
