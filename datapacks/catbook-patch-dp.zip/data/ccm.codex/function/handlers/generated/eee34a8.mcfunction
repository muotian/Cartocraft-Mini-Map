data modify storage codex:description_keys values append value {id:"yellow:enchantment/amethyst",related_keywords:["minecraft:enchantable/armor"]}
