data modify storage codex:description_keys values append value {id:"white:enchantment/wither_smite",related_keywords:["minecraft:enchantable/aoe_sharp_weapon"]}
