data modify storage codex:description_keys values append value {id:"yellow:enchantment/coal",related_keywords:["minecraft:enchantable/armor"]}
