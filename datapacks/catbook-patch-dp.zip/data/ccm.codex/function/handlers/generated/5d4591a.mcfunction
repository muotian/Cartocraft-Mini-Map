data modify storage codex:description_keys values append value {id:"yellow:enchantment/emerald",related_keywords:["minecraft:enchantable/armor"]}
