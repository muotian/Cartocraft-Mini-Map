data modify storage codex:description_keys values append value "yellow:enchantment/soul_gem"
data modify storage codex:description_keys values append value {id:"yellow:extra/soul_gem_effects",related_keywords:["minecraft:effect/night_vision",{id:"minecraft:effect/absorption",context_number:0}]}
