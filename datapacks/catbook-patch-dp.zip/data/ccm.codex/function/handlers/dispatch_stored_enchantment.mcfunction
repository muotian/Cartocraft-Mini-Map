execute if items entity @s contents *[stored_enchantments~[{enchantments:"#ccm.codex:holder/white/wither_smite"}]] run function ccm.codex:handlers/generated/a231a3d
execute if items entity @s contents *[stored_enchantments~[{enchantments:"#ccm.codex:holder/mini_light/coal_gem"}]] run function ccm.codex:handlers/generated/bff66d1
execute if items entity @s contents *[stored_enchantments~[{enchantments:"#ccm.codex:holder/mini_light/emerald_gem"}]] run function ccm.codex:handlers/generated/5d4591a
execute if items entity @s contents *[stored_enchantments~[{enchantments:"#ccm.codex:holder/mini_light/blaze_gem"}]] run function ccm.codex:handlers/generated/9b5a0c3
execute if items entity @s contents *[stored_enchantments~[{enchantments:"#ccm.codex:holder/mini_light/amethyst_gem"}]] run function ccm.codex:handlers/generated/eee34a8
execute if items entity @s contents *[stored_enchantments~[{enchantments:"#ccm.codex:holder/mini_light/redstone_gem"}]] run function ccm.codex:handlers/generated/44fa195
execute if items entity @s contents *[stored_enchantments~[{enchantments:"#ccm.codex:holder/mini_light/gunpowder_gem"}]] run function ccm.codex:handlers/generated/3d640df
execute if items entity @s contents *[stored_enchantments~[{enchantments:"#ccm.codex:holder/mini_light/soul_gem"}]] run function ccm.codex:handlers/generated/637f819
