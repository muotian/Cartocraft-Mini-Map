execute if items entity @s contents *[enchantments~[{enchantments:"#ccm.codex:holder/white/wither_smite"}]] run function ccm.codex:handlers/generated/331876d
execute if items entity @s contents *[enchantments~[{enchantments:"#ccm.codex:holder/mini_light/coal_gem"}]] run function ccm.codex:handlers/generated/4fc1a88
execute if items entity @s contents *[enchantments~[{enchantments:"#ccm.codex:holder/mini_light/emerald_gem"}]] run function ccm.codex:handlers/generated/e27c5bc
execute if items entity @s contents *[enchantments~[{enchantments:"#ccm.codex:holder/mini_light/blaze_gem"}]] run function ccm.codex:handlers/generated/1ff3071
execute if items entity @s contents *[enchantments~[{enchantments:"#ccm.codex:holder/mini_light/amethyst_gem"}]] run function ccm.codex:handlers/generated/148fe26
execute if items entity @s contents *[enchantments~[{enchantments:"#ccm.codex:holder/mini_light/redstone_gem"}]] run function ccm.codex:handlers/generated/efacadb
execute if items entity @s contents *[enchantments~[{enchantments:"#ccm.codex:holder/mini_light/gunpowder_gem"}]] run function ccm.codex:handlers/generated/5463788
execute if items entity @s contents *[enchantments~[{enchantments:"#ccm.codex:holder/mini_light/soul_gem"}]] run function ccm.codex:handlers/generated/c9b0803
