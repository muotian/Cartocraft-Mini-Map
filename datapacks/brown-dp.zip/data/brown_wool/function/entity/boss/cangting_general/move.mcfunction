

# 移動



execute if entity @p[distance=3.. ,tag=brown_wool.cangting_general.player] rotated ~ 0 run tp @s ^ ^ ^0.2
execute if entity @p[distance=..2.9 ,tag=brown_wool.cangting_general.player] rotated ~ 0 run tp @s ^ ^ ^-0.2



execute unless score @s brown_wool.cangting_general.move matches 1.. if entity @p[distance=..3.9 ,tag=brown_wool.cangting_general.player] run scoreboard players add @s brown_wool.cangting_general.move2 1
execute if score @s brown_wool.cangting_general.move2 matches 40.. run tag @s add brown_wool.cangting_general.move0
execute if score @s brown_wool.cangting_general.move2 matches 40.. run scoreboard players reset @s brown_wool.cangting_general.move2

execute if score @s brown_wool.cangting_general.move_random matches 1 if score @s brown_wool.cangting_general.move matches 20..40 rotated ~ 0 if block ^-0.11 ^ ^0.09 air run tp @s ^-0.11 ^ ^0.09
execute if score @s brown_wool.cangting_general.move_random matches 1 if score @s brown_wool.cangting_general.move matches 1..19 rotated ~ 0 if block ^0.07 ^ ^-0.13 air run tp @s ^0.07 ^ ^-0.13

execute if score @s brown_wool.cangting_general.move_random matches 2 if score @s brown_wool.cangting_general.move matches 20..40 rotated ~ 0 if block ^0.11 ^ ^0.09 air run tp @s ^0.11 ^ ^0.09
execute if score @s brown_wool.cangting_general.move_random matches 2 if score @s brown_wool.cangting_general.move matches 1..19 rotated ~ 0 if block ^-0.07 ^ ^-0.13 air run tp @s ^-0.07 ^ ^-0.13

execute if score @s brown_wool.cangting_general.move_random matches 3 if score @s brown_wool.cangting_general.move matches 20..40 rotated ~ 0 if block ^-0.09 ^ ^0.11 air run tp @s ^-0.09 ^ ^0.11
execute if score @s brown_wool.cangting_general.move_random matches 3 if score @s brown_wool.cangting_general.move matches 1..19 rotated ~ 0 if block ^0.11 ^ ^-0.09 air run tp @s ^0.11 ^ ^-0.09

execute if score @s brown_wool.cangting_general.move_random matches 4 if score @s brown_wool.cangting_general.move matches 20..40 rotated ~ 0 if block ^0.09 ^ ^0.11 air run tp @s ^0.09 ^ ^0.11
execute if score @s brown_wool.cangting_general.move_random matches 4 if score @s brown_wool.cangting_general.move matches 1..19 rotated ~ 0 if block ^-0.11 ^ ^-0.09 air run tp @s ^-0.11 ^ ^-0.09

execute if score @s brown_wool.cangting_general.move_random matches 5 if score @s brown_wool.cangting_general.move matches 20..40 rotated ~ 0 if block ^0.2 ^ ^ air run tp @s ^0.2 ^ ^
execute if score @s brown_wool.cangting_general.move_random matches 5 if score @s brown_wool.cangting_general.move matches 1..19 rotated ~ 0 if block ^0.06 ^ ^0.14 air run tp @s ^0.06 ^ ^0.14

execute if score @s brown_wool.cangting_general.move_random matches 6 if score @s brown_wool.cangting_general.move matches 20..40 rotated ~ 0 if block ^-0.2 ^ ^ air run tp @s ^-0.2 ^ ^
execute if score @s brown_wool.cangting_general.move_random matches 6 if score @s brown_wool.cangting_general.move matches 1..19 rotated ~ 0 if block ^-0.06 ^ ^0.14 air run tp @s ^-0.06 ^ ^0.14

execute if score @s brown_wool.cangting_general.move_random matches 7 if score @s brown_wool.cangting_general.move matches 20..40 rotated ~ 0 if block ^0.06 ^ ^-0.14 air run tp @s ^0.06 ^ ^-0.14
execute if score @s brown_wool.cangting_general.move_random matches 7 if score @s brown_wool.cangting_general.move matches 1..19 rotated ~ 0 if block ^-0.06 ^ ^0.14 air run tp @s ^-0.06 ^ ^0.14

execute if score @s brown_wool.cangting_general.move_random matches 8 if score @s brown_wool.cangting_general.move matches 20..40 rotated ~ 0 if block ^-0.06 ^ ^-0.14 air run tp @s ^-0.06 ^ ^-0.14
execute if score @s brown_wool.cangting_general.move_random matches 8 if score @s brown_wool.cangting_general.move matches 1..19 rotated ~ 0 if block ^0.06 ^ ^0.14 air run tp @s ^0.06 ^ ^0.14

execute if score @s brown_wool.cangting_general.move_random matches 9 if score @s brown_wool.cangting_general.move matches 20..40 rotated ~ 0 if block ^-0.1 ^ ^-0.1 air run tp @s ^-0.1 ^ ^-0.1
execute if score @s brown_wool.cangting_general.move_random matches 9 if score @s brown_wool.cangting_general.move matches 1..19 rotated ~ 0 if block ^0.1 ^ ^0.1 air run tp @s ^0.1 ^ ^0.1

execute if score @s brown_wool.cangting_general.move_random matches 10 if score @s brown_wool.cangting_general.move matches 20..40 rotated ~ 0 if block ^0.1 ^ ^-0.1 air run tp @s ^0.1 ^ ^-0.1
execute if score @s brown_wool.cangting_general.move_random matches 10 if score @s brown_wool.cangting_general.move matches 1..19 rotated ~ 0 if block ^-0.1 ^ ^0.1 air run tp @s ^-0.1 ^ ^0.1

execute if score @s brown_wool.cangting_general.move_random matches 11 if score @s brown_wool.cangting_general.move matches 20..40 rotated ~ 0 if block ^-0.1 ^ ^-0.1 air run tp @s ^-0.1 ^ ^-0.1
execute if score @s brown_wool.cangting_general.move_random matches 11 if score @s brown_wool.cangting_general.move matches 1..19 rotated ~ 0 if block ^-0.1 ^ ^0.1 air run tp @s ^-0.1 ^ ^0.1

execute if score @s brown_wool.cangting_general.move_random matches 12 if score @s brown_wool.cangting_general.move matches 20..40 rotated ~ 0 if block ^0.1 ^ ^-0.1 air run tp @s ^0.1 ^ ^-0.1
execute if score @s brown_wool.cangting_general.move_random matches 12 if score @s brown_wool.cangting_general.move matches 1..19 rotated ~ 0 if block ^0.1 ^ ^0.1 air run tp @s ^0.1 ^ ^0.1

execute if score @s brown_wool.cangting_general.move_random matches 13 if score @s brown_wool.cangting_general.move matches 20..40 rotated ~ 0 if block ^0.06 ^ ^-0.14 air run tp @s ^0.06 ^ ^-0.14
execute if score @s brown_wool.cangting_general.move_random matches 13 if score @s brown_wool.cangting_general.move matches 1..19 rotated ~ 0 if block ^0.06 ^ ^0.14 air run tp @s ^0.06 ^ ^0.14

execute if score @s brown_wool.cangting_general.move_random matches 14 if score @s brown_wool.cangting_general.move matches 20..40 rotated ~ 0 if block ^-0.06 ^ ^-0.14 air run tp @s ^-0.06 ^ ^-0.14
execute if score @s brown_wool.cangting_general.move_random matches 14 if score @s brown_wool.cangting_general.move matches 1..19 rotated ~ 0 if block ^-0.06 ^ ^0.14 air run tp @s ^-0.06 ^ ^0.14

execute if score @s brown_wool.cangting_general.move_random matches 15 if score @s brown_wool.cangting_general.move matches 20..40 rotated ~ 0 if block ^0.06 ^ ^-0.14 air run tp @s ^0.06 ^ ^-0.14
execute if score @s brown_wool.cangting_general.move_random matches 15 if score @s brown_wool.cangting_general.move matches 1..19 rotated ~ 0 if block ^0.2 ^ ^ air run tp @s ^0.2 ^ ^

execute if score @s brown_wool.cangting_general.move_random matches 16 if score @s brown_wool.cangting_general.move matches 20..40 rotated ~ 0 if block ^-0.06 ^ ^-0.14 air run tp @s ^-0.06 ^ ^-0.14
execute if score @s brown_wool.cangting_general.move_random matches 16 if score @s brown_wool.cangting_general.move matches 1..19 rotated ~ 0 if block ^-0.2 ^ ^ air run tp @s ^-0.2 ^ ^

execute unless score @s brown_wool.cangting_general.move matches 1.. if entity @p[distance=2.9..3.1 ,tag=brown_wool.cangting_general.player] run tag @s add brown_wool.cangting_general.move0
execute if entity @s[tag=brown_wool.cangting_general.move0] unless score @s brown_wool.cangting_general.move matches 1.. store result score @s brown_wool.cangting_general.move_random run random value 1..16


execute unless score @s brown_wool.cangting_general.move matches 1.. if score @s brown_wool.cangting_general.move_random matches 1 run scoreboard players set @s brown_wool.cangting_general.move 40
execute unless score @s brown_wool.cangting_general.move matches 1.. if score @s brown_wool.cangting_general.move_random matches 2 run scoreboard players set @s brown_wool.cangting_general.move 40
execute unless score @s brown_wool.cangting_general.move matches 1.. if score @s brown_wool.cangting_general.move_random matches 3 run scoreboard players set @s brown_wool.cangting_general.move 40
execute unless score @s brown_wool.cangting_general.move matches 1.. if score @s brown_wool.cangting_general.move_random matches 4 run scoreboard players set @s brown_wool.cangting_general.move 40
execute unless score @s brown_wool.cangting_general.move matches 1.. if score @s brown_wool.cangting_general.move_random matches 5 run scoreboard players set @s brown_wool.cangting_general.move 40
execute unless score @s brown_wool.cangting_general.move matches 1.. if score @s brown_wool.cangting_general.move_random matches 6 run scoreboard players set @s brown_wool.cangting_general.move 40
execute unless score @s brown_wool.cangting_general.move matches 1.. if score @s brown_wool.cangting_general.move_random matches 7 run scoreboard players set @s brown_wool.cangting_general.move 40
execute unless score @s brown_wool.cangting_general.move matches 1.. if score @s brown_wool.cangting_general.move_random matches 8 run scoreboard players set @s brown_wool.cangting_general.move 40
execute unless score @s brown_wool.cangting_general.move matches 1.. if score @s brown_wool.cangting_general.move_random matches 9 run scoreboard players set @s brown_wool.cangting_general.move 40
execute unless score @s brown_wool.cangting_general.move matches 1.. if score @s brown_wool.cangting_general.move_random matches 10 run scoreboard players set @s brown_wool.cangting_general.move 40
execute unless score @s brown_wool.cangting_general.move matches 1.. if score @s brown_wool.cangting_general.move_random matches 11 run scoreboard players set @s brown_wool.cangting_general.move 40
execute unless score @s brown_wool.cangting_general.move matches 1.. if score @s brown_wool.cangting_general.move_random matches 12 run scoreboard players set @s brown_wool.cangting_general.move 40
execute unless score @s brown_wool.cangting_general.move matches 1.. if score @s brown_wool.cangting_general.move_random matches 13 run scoreboard players set @s brown_wool.cangting_general.move 40
execute unless score @s brown_wool.cangting_general.move matches 1.. if score @s brown_wool.cangting_general.move_random matches 14 run scoreboard players set @s brown_wool.cangting_general.move 40
execute unless score @s brown_wool.cangting_general.move matches 1.. if score @s brown_wool.cangting_general.move_random matches 15 run scoreboard players set @s brown_wool.cangting_general.move 40
execute unless score @s brown_wool.cangting_general.move matches 1.. if score @s brown_wool.cangting_general.move_random matches 16 run scoreboard players set @s brown_wool.cangting_general.move 40

execute if block ~ ~-0.1 ~ air run function brown_wool:entity/boss/cangting_general/return

execute if entity @n[distance=25.. ,tag=brown_wool.cangting_general.terrain ,type=marker ,limit=1] run function brown_wool:entity/boss/cangting_general/return


execute if entity @s[tag=brown_wool.cangting_general.move0] if score @s brown_wool.cangting_general.move matches 1 run scoreboard players reset @s brown_wool.cangting_general.move_random
execute if entity @s[tag=brown_wool.cangting_general.move0] if score @s brown_wool.cangting_general.move matches 1 run tag @s remove brown_wool.cangting_general.move0

scoreboard players remove @s[scores={brown_wool.cangting_general.move=1..}] brown_wool.cangting_general.move 1

execute run rotate @s facing entity @p[tag=brown_wool.cangting_general.player]

