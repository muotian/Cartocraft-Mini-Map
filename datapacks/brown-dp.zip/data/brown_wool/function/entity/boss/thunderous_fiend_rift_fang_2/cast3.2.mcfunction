
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~0.5 ~ ~11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~1.5 ~ ~11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~2.5 ~ ~11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~2.5 ~ ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~3.5 ~ ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~4.5 ~ ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~5.5 ~ ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~5.5 ~ ~9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~6.5 ~ ~9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~6.5 ~ ~8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~7.5 ~ ~8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~8.5 ~ ~8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~8.5 ~ ~7.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~8.5 ~ ~6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~9.5 ~ ~6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~9.5 ~ ~5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~ ~5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~ ~4.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~ ~3.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~ ~2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~11.5 ~ ~2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~11.5 ~ ~1.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~11.5 ~ ~0.5 air


execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-0.5 ~ ~11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-1.5 ~ ~11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-2.5 ~ ~11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-2.5 ~ ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-3.5 ~ ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-4.5 ~ ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-5.5 ~ ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-5.5 ~ ~9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-6.5 ~ ~9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-6.5 ~ ~8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-7.5 ~ ~8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-8.5 ~ ~8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-8.5 ~ ~7.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-8.5 ~ ~6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-9.5 ~ ~6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-9.5 ~ ~5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~ ~5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~ ~4.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~ ~3.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~ ~2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-11.5 ~ ~2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-11.5 ~ ~1.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-11.5 ~ ~0.5 air




execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~0.5 ~ ~-11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~1.5 ~ ~-11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~2.5 ~ ~-11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~2.5 ~ ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~3.5 ~ ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~4.5 ~ ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~5.5 ~ ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~5.5 ~ ~-9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~6.5 ~ ~-9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~6.5 ~ ~-8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~7.5 ~ ~-8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~8.5 ~ ~-8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~8.5 ~ ~-7.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~8.5 ~ ~-6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~9.5 ~ ~-6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~9.5 ~ ~-5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~ ~-5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~ ~-4.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~ ~-3.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~ ~-2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~11.5 ~ ~-2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~11.5 ~ ~-1.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~11.5 ~ ~-0.5 air





execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-0.5 ~ ~-11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-1.5 ~ ~-11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-2.5 ~ ~-11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-2.5 ~ ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-3.5 ~ ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-4.5 ~ ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-5.5 ~ ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-5.5 ~ ~-9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-6.5 ~ ~-9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-6.5 ~ ~-8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-7.5 ~ ~-8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-8.5 ~ ~-8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-8.5 ~ ~-7.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-8.5 ~ ~-6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-9.5 ~ ~-6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-9.5 ~ ~-5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~ ~-5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~ ~-4.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~ ~-3.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~ ~-2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-11.5 ~ ~-2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-11.5 ~ ~-1.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-11.5 ~ ~-0.5 air





execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~0.5 ~1 ~11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~1.5 ~1 ~11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~2.5 ~1 ~11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~2.5 ~1 ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~3.5 ~1 ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~4.5 ~1 ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~5.5 ~1 ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~5.5 ~1 ~9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~6.5 ~1 ~9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~6.5 ~1 ~8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~7.5 ~1 ~8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~8.5 ~1 ~8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~8.5 ~1 ~7.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~8.5 ~1 ~6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~9.5 ~1 ~6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~9.5 ~1 ~5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~1 ~5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~1 ~4.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~1 ~3.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~1 ~2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~11.5 ~1 ~2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~11.5 ~1 ~1.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~11.5 ~1 ~0.5 air


execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-0.5 ~1 ~11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-1.5 ~1 ~11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-2.5 ~1 ~11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-2.5 ~1 ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-3.5 ~1 ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-4.5 ~1 ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-5.5 ~1 ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-5.5 ~1 ~9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-6.5 ~1 ~9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-6.5 ~1 ~8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-7.5 ~1 ~8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-8.5 ~1 ~8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-8.5 ~1 ~7.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-8.5 ~1 ~6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-9.5 ~1 ~6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-9.5 ~1 ~5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~1 ~5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~1 ~4.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~1 ~3.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~1 ~2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-11.5 ~1 ~2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-11.5 ~1 ~1.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-11.5 ~1 ~0.5 air




execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~0.5 ~1 ~-11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~1.5 ~1 ~-11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~2.5 ~1 ~-11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~2.5 ~1 ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~3.5 ~1 ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~4.5 ~1 ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~5.5 ~1 ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~5.5 ~1 ~-9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~6.5 ~1 ~-9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~6.5 ~1 ~-8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~7.5 ~1 ~-8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~8.5 ~1 ~-8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~8.5 ~1 ~-7.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~8.5 ~1 ~-6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~9.5 ~1 ~-6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~9.5 ~1 ~-5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~1 ~-5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~1 ~-4.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~1 ~-3.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~1 ~-2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~11.5 ~1 ~-2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~11.5 ~1 ~-1.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~11.5 ~1 ~-0.5 air





execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-0.5 ~1 ~-11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-1.5 ~1 ~-11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-2.5 ~1 ~-11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-2.5 ~1 ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-3.5 ~1 ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-4.5 ~1 ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-5.5 ~1 ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-5.5 ~1 ~-9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-6.5 ~1 ~-9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-6.5 ~1 ~-8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-7.5 ~1 ~-8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-8.5 ~1 ~-8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-8.5 ~1 ~-7.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-8.5 ~1 ~-6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-9.5 ~1 ~-6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-9.5 ~1 ~-5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~1 ~-5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~1 ~-4.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~1 ~-3.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~1 ~-2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-11.5 ~1 ~-2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-11.5 ~1 ~-1.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-11.5 ~1 ~-0.5 air






execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~0.5 ~2 ~11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~1.5 ~2 ~11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~2.5 ~2 ~11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~2.5 ~2 ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~3.5 ~2 ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~4.5 ~2 ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~5.5 ~2 ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~5.5 ~2 ~9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~6.5 ~2 ~9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~6.5 ~2 ~8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~7.5 ~2 ~8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~8.5 ~2 ~8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~8.5 ~2 ~7.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~8.5 ~2 ~6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~9.5 ~2 ~6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~9.5 ~2 ~5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~2 ~5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~2 ~4.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~2 ~3.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~2 ~2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~11.5 ~2 ~2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~11.5 ~2 ~1.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~11.5 ~2 ~0.5 air


execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-0.5 ~2 ~11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-1.5 ~2 ~11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-2.5 ~2 ~11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-2.5 ~2 ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-3.5 ~2 ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-4.5 ~2 ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-5.5 ~2 ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-5.5 ~2 ~9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-6.5 ~2 ~9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-6.5 ~2 ~8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-7.5 ~2 ~8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-8.5 ~2 ~8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-8.5 ~2 ~7.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-8.5 ~2 ~6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-9.5 ~2 ~6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-9.5 ~2 ~5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~2 ~5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~2 ~4.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~2 ~3.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~2 ~2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-11.5 ~2 ~2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-11.5 ~2 ~1.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-11.5 ~2 ~0.5 air




execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~0.5 ~2 ~-11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~1.5 ~2 ~-11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~2.5 ~2 ~-11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~2.5 ~2 ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~3.5 ~2 ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~4.5 ~2 ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~5.5 ~2 ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~5.5 ~2 ~-9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~6.5 ~2 ~-9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~6.5 ~2 ~-8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~7.5 ~2 ~-8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~8.5 ~2 ~-8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~8.5 ~2 ~-7.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~8.5 ~2 ~-6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~9.5 ~2 ~-6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~9.5 ~2 ~-5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~2 ~-5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~2 ~-4.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~2 ~-3.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~2 ~-2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~11.5 ~2 ~-2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~11.5 ~2 ~-1.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~11.5 ~2 ~-0.5 air





execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-0.5 ~2 ~-11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-1.5 ~2 ~-11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-2.5 ~2 ~-11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-2.5 ~2 ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-3.5 ~2 ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-4.5 ~2 ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-5.5 ~2 ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-5.5 ~2 ~-9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-6.5 ~2 ~-9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-6.5 ~2 ~-8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-7.5 ~2 ~-8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-8.5 ~2 ~-8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-8.5 ~2 ~-7.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-8.5 ~2 ~-6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-9.5 ~2 ~-6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-9.5 ~2 ~-5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~2 ~-5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~2 ~-4.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~2 ~-3.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~2 ~-2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-11.5 ~2 ~-2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-11.5 ~2 ~-1.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-11.5 ~2 ~-0.5 air






execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~0.5 ~3 ~11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~1.5 ~3 ~11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~2.5 ~3 ~11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~2.5 ~3 ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~3.5 ~3 ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~4.5 ~3 ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~5.5 ~3 ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~5.5 ~3 ~9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~6.5 ~3 ~9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~6.5 ~3 ~8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~7.5 ~3 ~8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~8.5 ~3 ~8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~8.5 ~3 ~7.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~8.5 ~3 ~6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~9.5 ~3 ~6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~9.5 ~3 ~5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~3 ~5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~3 ~4.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~3 ~3.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~3 ~2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~11.5 ~3 ~2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~11.5 ~3 ~1.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~11.5 ~3 ~0.5 air


execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-0.5 ~3 ~11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-1.5 ~3 ~11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-2.5 ~3 ~11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-2.5 ~3 ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-3.5 ~3 ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-4.5 ~3 ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-5.5 ~3 ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-5.5 ~3 ~9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-6.5 ~3 ~9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-6.5 ~3 ~8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-7.5 ~3 ~8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-8.5 ~3 ~8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-8.5 ~3 ~7.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-8.5 ~3 ~6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-9.5 ~3 ~6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-9.5 ~3 ~5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~3 ~5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~3 ~4.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~3 ~3.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~3 ~2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-11.5 ~3 ~2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-11.5 ~3 ~1.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-11.5 ~3 ~0.5 air




execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~0.5 ~3 ~-11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~1.5 ~3 ~-11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~2.5 ~3 ~-11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~2.5 ~3 ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~3.5 ~3 ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~4.5 ~3 ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~5.5 ~3 ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~5.5 ~3 ~-9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~6.5 ~3 ~-9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~6.5 ~3 ~-8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~7.5 ~3 ~-8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~8.5 ~3 ~-8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~8.5 ~3 ~-7.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~8.5 ~3 ~-6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~9.5 ~3 ~-6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~9.5 ~3 ~-5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~3 ~-5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~3 ~-4.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~3 ~-3.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~3 ~-2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~11.5 ~3 ~-2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~11.5 ~3 ~-1.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~11.5 ~3 ~-0.5 air





execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-0.5 ~3 ~-11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-1.5 ~3 ~-11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-2.5 ~3 ~-11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-2.5 ~3 ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-3.5 ~3 ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-4.5 ~3 ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-5.5 ~3 ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-5.5 ~3 ~-9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-6.5 ~3 ~-9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-6.5 ~3 ~-8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-7.5 ~3 ~-8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-8.5 ~3 ~-8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-8.5 ~3 ~-7.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-8.5 ~3 ~-6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-9.5 ~3 ~-6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-9.5 ~3 ~-5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~3 ~-5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~3 ~-4.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~3 ~-3.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~3 ~-2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-11.5 ~3 ~-2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-11.5 ~3 ~-1.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-11.5 ~3 ~-0.5 air






execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~0.5 ~4 ~11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~1.5 ~4 ~11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~2.5 ~4 ~11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~2.5 ~4 ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~3.5 ~4 ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~4.5 ~4 ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~5.5 ~4 ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~5.5 ~4 ~9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~6.5 ~4 ~9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~6.5 ~4 ~8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~7.5 ~4 ~8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~8.5 ~4 ~8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~8.5 ~4 ~7.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~8.5 ~4 ~6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~9.5 ~4 ~6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~9.5 ~4 ~5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~4 ~5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~4 ~4.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~4 ~3.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~4 ~2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~11.5 ~4 ~2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~11.5 ~4 ~1.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~11.5 ~4 ~0.5 air


execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-0.5 ~4 ~11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-1.5 ~4 ~11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-2.5 ~4 ~11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-2.5 ~4 ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-3.5 ~4 ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-4.5 ~4 ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-5.5 ~4 ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-5.5 ~4 ~9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-6.5 ~4 ~9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-6.5 ~4 ~8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-7.5 ~4 ~8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-8.5 ~4 ~8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-8.5 ~4 ~7.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-8.5 ~4 ~6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-9.5 ~4 ~6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-9.5 ~4 ~5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~4 ~5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~4 ~4.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~4 ~3.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~4 ~2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-11.5 ~4 ~2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-11.5 ~4 ~1.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-11.5 ~4 ~0.5 air




execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~0.5 ~4 ~-11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~1.5 ~4 ~-11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~2.5 ~4 ~-11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~2.5 ~4 ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~3.5 ~4 ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~4.5 ~4 ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~5.5 ~4 ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~5.5 ~4 ~-9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~6.5 ~4 ~-9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~6.5 ~4 ~-8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~7.5 ~4 ~-8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~8.5 ~4 ~-8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~8.5 ~4 ~-7.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~8.5 ~4 ~-6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~9.5 ~4 ~-6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~9.5 ~4 ~-5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~4 ~-5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~4 ~-4.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~4 ~-3.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~4 ~-2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~11.5 ~4 ~-2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~11.5 ~4 ~-1.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~11.5 ~4 ~-0.5 air





execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-0.5 ~4 ~-11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-1.5 ~4 ~-11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-2.5 ~4 ~-11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-2.5 ~4 ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-3.5 ~4 ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-4.5 ~4 ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-5.5 ~4 ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-5.5 ~4 ~-9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-6.5 ~4 ~-9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-6.5 ~4 ~-8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-7.5 ~4 ~-8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-8.5 ~4 ~-8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-8.5 ~4 ~-7.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-8.5 ~4 ~-6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-9.5 ~4 ~-6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-9.5 ~4 ~-5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~4 ~-5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~4 ~-4.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~4 ~-3.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~4 ~-2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-11.5 ~4 ~-2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-11.5 ~4 ~-1.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-11.5 ~4 ~-0.5 air




execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~0.5 ~5 ~11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~1.5 ~5 ~11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~2.5 ~5 ~11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~2.5 ~5 ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~3.5 ~5 ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~4.5 ~5 ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~5.5 ~5 ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~5.5 ~5 ~9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~6.5 ~5 ~9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~6.5 ~5 ~8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~7.5 ~5 ~8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~8.5 ~5 ~8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~8.5 ~5 ~7.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~8.5 ~5 ~6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~9.5 ~5 ~6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~9.5 ~5 ~5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~5 ~5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~5 ~4.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~5 ~3.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~5 ~2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~11.5 ~5 ~2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~11.5 ~5 ~1.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~11.5 ~5 ~0.5 air


execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-0.5 ~5 ~11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-1.5 ~5 ~11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-2.5 ~5 ~11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-2.5 ~5 ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-3.5 ~5 ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-4.5 ~5 ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-5.5 ~5 ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-5.5 ~5 ~9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-6.5 ~5 ~9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-6.5 ~5 ~8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-7.5 ~5 ~8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-8.5 ~5 ~8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-8.5 ~5 ~7.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-8.5 ~5 ~6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-9.5 ~5 ~6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-9.5 ~5 ~5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~5 ~5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~5 ~4.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~5 ~3.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~5 ~2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-11.5 ~5 ~2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-11.5 ~5 ~1.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-11.5 ~5 ~0.5 air




execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~0.5 ~5 ~-11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~1.5 ~5 ~-11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~2.5 ~5 ~-11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~2.5 ~5 ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~3.5 ~5 ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~4.5 ~5 ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~5.5 ~5 ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~5.5 ~5 ~-9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~6.5 ~5 ~-9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~6.5 ~5 ~-8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~7.5 ~5 ~-8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~8.5 ~5 ~-8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~8.5 ~5 ~-7.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~8.5 ~5 ~-6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~9.5 ~5 ~-6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~9.5 ~5 ~-5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~5 ~-5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~5 ~-4.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~5 ~-3.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~5 ~-2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~11.5 ~5 ~-2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~11.5 ~5 ~-1.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~11.5 ~5 ~-0.5 air





execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-0.5 ~5 ~-11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-1.5 ~5 ~-11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-2.5 ~5 ~-11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-2.5 ~5 ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-3.5 ~5 ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-4.5 ~5 ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-5.5 ~5 ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-5.5 ~5 ~-9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-6.5 ~5 ~-9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-6.5 ~5 ~-8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-7.5 ~5 ~-8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-8.5 ~5 ~-8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-8.5 ~5 ~-7.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-8.5 ~5 ~-6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-9.5 ~5 ~-6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-9.5 ~5 ~-5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~5 ~-5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~5 ~-4.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~5 ~-3.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~5 ~-2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-11.5 ~5 ~-2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-11.5 ~5 ~-1.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-11.5 ~5 ~-0.5 air















execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~0.5 ~6 ~11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~1.5 ~6 ~11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~2.5 ~6 ~11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~2.5 ~6 ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~3.5 ~6 ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~4.5 ~6 ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~5.5 ~6 ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~5.5 ~6 ~9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~6.5 ~6 ~9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~6.5 ~6 ~8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~7.5 ~6 ~8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~8.5 ~6 ~8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~8.5 ~6 ~7.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~8.5 ~6 ~6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~9.5 ~6 ~6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~9.5 ~6 ~5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~6 ~5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~6 ~4.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~6 ~3.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~6 ~2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~11.5 ~6 ~2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~11.5 ~6 ~1.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~11.5 ~6 ~0.5 air


execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-0.5 ~6 ~11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-1.5 ~6 ~11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-2.5 ~6 ~11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-2.5 ~6 ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-3.5 ~6 ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-4.5 ~6 ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-5.5 ~6 ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-5.5 ~6 ~9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-6.5 ~6 ~9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-6.5 ~6 ~8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-7.5 ~6 ~8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-8.5 ~6 ~8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-8.5 ~6 ~7.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-8.5 ~6 ~6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-9.5 ~6 ~6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-9.5 ~6 ~5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~6 ~5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~6 ~4.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~6 ~3.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~6 ~2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-11.5 ~6 ~2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-11.5 ~6 ~1.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-11.5 ~6 ~0.5 air




execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~0.5 ~6 ~-11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~1.5 ~6 ~-11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~2.5 ~6 ~-11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~2.5 ~6 ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~3.5 ~6 ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~4.5 ~6 ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~5.5 ~6 ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~5.5 ~6 ~-9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~6.5 ~6 ~-9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~6.5 ~6 ~-8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~7.5 ~6 ~-8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~8.5 ~6 ~-8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~8.5 ~6 ~-7.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~8.5 ~6 ~-6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~9.5 ~6 ~-6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~9.5 ~6 ~-5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~6 ~-5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~6 ~-4.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~6 ~-3.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~6 ~-2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~11.5 ~6 ~-2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~11.5 ~6 ~-1.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~11.5 ~6 ~-0.5 air





execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-0.5 ~6 ~-11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-1.5 ~6 ~-11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-2.5 ~6 ~-11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-2.5 ~6 ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-3.5 ~6 ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-4.5 ~6 ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-5.5 ~6 ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-5.5 ~6 ~-9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-6.5 ~6 ~-9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-6.5 ~6 ~-8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-7.5 ~6 ~-8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-8.5 ~6 ~-8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-8.5 ~6 ~-7.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-8.5 ~6 ~-6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-9.5 ~6 ~-6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-9.5 ~6 ~-5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~6 ~-5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~6 ~-4.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~6 ~-3.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~6 ~-2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-11.5 ~6 ~-2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-11.5 ~6 ~-1.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-11.5 ~6 ~-0.5 air






execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~0.5 ~7 ~11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~1.5 ~7 ~11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~2.5 ~7 ~11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~2.5 ~7 ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~3.5 ~7 ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~4.5 ~7 ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~5.5 ~7 ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~5.5 ~7 ~9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~6.5 ~7 ~9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~6.5 ~7 ~8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~7.5 ~7 ~8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~8.5 ~7 ~8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~8.5 ~7 ~7.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~8.5 ~7 ~6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~9.5 ~7 ~6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~9.5 ~7 ~5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~7 ~5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~7 ~4.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~7 ~3.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~7 ~2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~11.5 ~7 ~2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~11.5 ~7 ~1.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~11.5 ~7 ~0.5 air


execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-0.5 ~7 ~11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-1.5 ~7 ~11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-2.5 ~7 ~11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-2.5 ~7 ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-3.5 ~7 ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-4.5 ~7 ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-5.5 ~7 ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-5.5 ~7 ~9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-6.5 ~7 ~9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-6.5 ~7 ~8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-7.5 ~7 ~8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-8.5 ~7 ~8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-8.5 ~7 ~7.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-8.5 ~7 ~6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-9.5 ~7 ~6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-9.5 ~7 ~5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~7 ~5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~7 ~4.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~7 ~3.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~7 ~2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-11.5 ~7 ~2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-11.5 ~7 ~1.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-11.5 ~7 ~0.5 air




execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~0.5 ~7 ~-11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~1.5 ~7 ~-11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~2.5 ~7 ~-11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~2.5 ~7 ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~3.5 ~7 ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~4.5 ~7 ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~5.5 ~7 ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~5.5 ~7 ~-9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~6.5 ~7 ~-9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~6.5 ~7 ~-8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~7.5 ~7 ~-8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~8.5 ~7 ~-8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~8.5 ~7 ~-7.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~8.5 ~7 ~-6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~9.5 ~7 ~-6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~9.5 ~7 ~-5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~7 ~-5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~7 ~-4.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~7 ~-3.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~7 ~-2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~11.5 ~7 ~-2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~11.5 ~7 ~-1.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~11.5 ~7 ~-0.5 air





execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-0.5 ~7 ~-11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-1.5 ~7 ~-11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-2.5 ~7 ~-11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-2.5 ~7 ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-3.5 ~7 ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-4.5 ~7 ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-5.5 ~7 ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-5.5 ~7 ~-9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-6.5 ~7 ~-9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-6.5 ~7 ~-8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-7.5 ~7 ~-8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-8.5 ~7 ~-8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-8.5 ~7 ~-7.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-8.5 ~7 ~-6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-9.5 ~7 ~-6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-9.5 ~7 ~-5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~7 ~-5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~7 ~-4.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~7 ~-3.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~7 ~-2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-11.5 ~7 ~-2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-11.5 ~7 ~-1.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-11.5 ~7 ~-0.5 air




execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~0.5 ~8 ~11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~1.5 ~8 ~11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~2.5 ~8 ~11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~2.5 ~8 ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~3.5 ~8 ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~4.5 ~8 ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~5.5 ~8 ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~5.5 ~8 ~9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~6.5 ~8 ~9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~6.5 ~8 ~8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~7.5 ~8 ~8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~8.5 ~8 ~8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~8.5 ~8 ~7.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~8.5 ~8 ~6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~9.5 ~8 ~6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~9.5 ~8 ~5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~8 ~5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~8 ~4.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~8 ~3.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~8 ~2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~11.5 ~8 ~2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~11.5 ~8 ~1.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~11.5 ~8 ~0.5 air


execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-0.5 ~8 ~11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-1.5 ~8 ~11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-2.5 ~8 ~11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-2.5 ~8 ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-3.5 ~8 ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-4.5 ~8 ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-5.5 ~8 ~10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-5.5 ~8 ~9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-6.5 ~8 ~9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-6.5 ~8 ~8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-7.5 ~8 ~8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-8.5 ~8 ~8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-8.5 ~8 ~7.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-8.5 ~8 ~6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-9.5 ~8 ~6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-9.5 ~8 ~5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~8 ~5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~8 ~4.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~8 ~3.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~8 ~2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-11.5 ~8 ~2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-11.5 ~8 ~1.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-11.5 ~8 ~0.5 air




execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~0.5 ~8 ~-11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~1.5 ~8 ~-11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~2.5 ~8 ~-11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~2.5 ~8 ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~3.5 ~8 ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~4.5 ~8 ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~5.5 ~8 ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~5.5 ~8 ~-9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~6.5 ~8 ~-9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~6.5 ~8 ~-8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~7.5 ~8 ~-8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~8.5 ~8 ~-8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~8.5 ~8 ~-7.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~8.5 ~8 ~-6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~9.5 ~8 ~-6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~9.5 ~8 ~-5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~8 ~-5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~8 ~-4.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~8 ~-3.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~10.5 ~8 ~-2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~11.5 ~8 ~-2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~11.5 ~8 ~-1.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~11.5 ~8 ~-0.5 air





execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-0.5 ~8 ~-11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-1.5 ~8 ~-11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-2.5 ~8 ~-11.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-2.5 ~8 ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-3.5 ~8 ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-4.5 ~8 ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-5.5 ~8 ~-10.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-5.5 ~8 ~-9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-6.5 ~8 ~-9.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-6.5 ~8 ~-8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-7.5 ~8 ~-8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-8.5 ~8 ~-8.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-8.5 ~8 ~-7.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-8.5 ~8 ~-6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-9.5 ~8 ~-6.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-9.5 ~8 ~-5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~8 ~-5.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~8 ~-4.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~8 ~-3.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-10.5 ~8 ~-2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-11.5 ~8 ~-2.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-11.5 ~8 ~-1.5 air
execute as @e[type=marker, tag=brown_wool.thunderous_fiend_rift_fang.terrain ,limit=1] at @s run setblock ~-11.5 ~8 ~-0.5 air


