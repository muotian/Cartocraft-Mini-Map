# 這個函數會召喚一隻雷紋衛士，效果是
# 

summon skeleton ~ ~ ~ {CustomName:{translate:"entity.brown_wool.thunder_guardian",color:"aqua"},Tags:["brown_wool.thunder_guardian"],attributes:[{id:armor,base:20},{id:max_health,base:30},{id:movement_speed,base:0.265}],equipment:{mainhand:{id:bow,components:{enchantments:{power:4}}},chest:{id:diamond_chestplate,components:{trim:{pattern:eye,material:amethyst},attribute_modifiers:[{type:armor,amount:0,operation:add_value,id:"1766046898431"}]}},head:{id:diamond_helmet,components:{trim:{pattern:silence,material:amethyst},attribute_modifiers:[{type:armor,amount:0,operation:add_value,id:"1766046898431"}]}}},Health:999,DeathLootTable:"brown_wool:lightning_crystal",drop_chances:{mainhand:0,chest:0,head:0}}








