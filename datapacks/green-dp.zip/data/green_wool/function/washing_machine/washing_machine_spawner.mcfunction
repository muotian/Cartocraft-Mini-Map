function green_wool:washing_machine/washing_machine_summon
kill @s