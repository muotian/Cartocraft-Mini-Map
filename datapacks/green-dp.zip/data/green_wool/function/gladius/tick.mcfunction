function green_wool:gladius/gladius_energy
